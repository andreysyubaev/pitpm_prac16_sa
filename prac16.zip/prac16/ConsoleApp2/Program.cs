﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("выберите тип сотрудника: ");
            Console.WriteLine("1 - совместитель\n2 - постоянный");
            int n = int.Parse(Console.ReadLine());
            if (n == 1)
            {
                Parttime sotr1 = new Parttime();
                sotr1.SetSurmane("name");
            }
        }
    }
}
