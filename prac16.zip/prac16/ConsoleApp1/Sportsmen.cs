﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Sportsmen
    {
        string name;
        string otc;
        string surname;
        string gender;
        int year;
        double weight;
        string sport;
        public string GetName()
        {
            return name;
        }

        public string GetOtc()
        {
            return otc;
        }

        public string GetSurname()
        {
            return surname;
        }

        public string GetGender()
        {
            return gender;
        }

        public int GetYear()
        {
            return year;
        }

        public double GetWeight()
        {
            return weight;
        }

        public string GetSport()
        {
            return sport;
        }
    }
}
