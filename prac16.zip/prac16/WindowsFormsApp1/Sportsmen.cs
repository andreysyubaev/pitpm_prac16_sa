﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Sportsmen
    {
        public Sportsmen(string name, string otc, string surname, string gender, double height, double weight, string sport)
        {
            this.name = name;
            this.otc = otc;
            this.surname = surname;
            this.gender = gender;
            this.height = height;
            this.weight = weight;
            this.sport = sport;

        }

        public static int kolvo;
        public static double allweight;
        string name;
        string otc;
        string surname;
        string gender;
        double height = 0;
        double weight = 0;
        string sport;
       
        public string GetName()
        {
            return name;
        }

        public void SetName(string a)
        {
            name = a;
        }

        public string GetOtc()
        {
            return otc;
        }

        public void SetOtc(string a)
        {
            otc = a;
        }

        public string GetSurname()
        {
            return surname;
        }

        public void SetSurname(string a)
        {
            surname = a;
        }

        public string GetGender()
        {
            return gender;
        }

        public void SetGender(string a)
        {
            gender = a;
        }

        public double GetHeight()
        {
            return height;
        }
        
        public void SetHeight(double a)
        {
            height = a;
        }

        public double GetWeight()
        {
            return weight;
        }

        public void SetWeight(double a)
        {
            weight = a;
        }

        public string GetSport()
        {
            return sport;
        }

        public void SetSport(string a)
        {
            sport = a;
        }

    
        public string GetStatus()
        {
            double imt = weight / Math.Pow(height / 100, 2);
            string status = "";
            if (imt < 18.6)
                status = "Нужно поправиться";
            else if (imt > 25)
                status = "Нужно похудеть";
            else
                status = "ОК";
            return status;
        }

        public double GetGoodweight()
        {
            double goodweight = 0;
            if (gender == "Мужчина")
                goodweight = (Convert.ToDouble(GetHeight()) * 4.0 / 2.54 - 128) * 0.453;
            else if (gender == "Женщина")
                goodweight = (Convert.ToDouble(GetHeight()) * 3.5 / 2.54 - 108) * 0.453;
            return goodweight;
        }
    }
}
