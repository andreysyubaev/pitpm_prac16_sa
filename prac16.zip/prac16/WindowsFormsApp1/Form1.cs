﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private IList<Sportsmen> sportsmenList = new List<Sportsmen>();
        private DataGridViewColumn dataGridViewColumn1 = null;
        private DataGridViewColumn dataGridViewColumn2 = null;
        private DataGridViewColumn dataGridViewColumn3 = null;
        private DataGridViewColumn dataGridViewColumn4 = null;
        private DataGridViewColumn dataGridViewColumn5 = null;
        private DataGridViewColumn dataGridViewColumn6 = null;
        private DataGridViewColumn dataGridViewColumn7 = null;
        private DataGridViewColumn dataGridViewColumn8 = null;
        private DataGridViewColumn dataGridViewColumn9 = null;
        private DataGridViewColumn dataGridViewColumn10 = null;

        private void addSportsmen(string name, string otc, string surname, string gender, double height, double weight, string sport)
        {
            Sportsmen sportsmen1 = new Sportsmen(name, otc, surname, gender, height, weight, sport);
            sportsmenList.Add(sportsmen1);
            Sportsmen.kolvo++;
            Sportsmen.allweight += weight;
            showListInGrid();
        }
        
        private void avgWeight()
        {

        }

        private void showListInGrid()
        {
            dataGridView1.Rows.Clear();
            foreach (Sportsmen s in sportsmenList)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell2 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell3 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell4 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell5 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell6 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell7 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell8 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell9 = new DataGridViewTextBoxCell();

                cell1.ValueType = typeof(string);
                cell1.Value = s.GetName();
                cell2.ValueType = typeof(string);
                cell2.Value = s.GetOtc();
                cell3.ValueType = typeof(string);
                cell3.Value = s.GetSurname();
                cell4.ValueType = typeof(string);
                cell4.Value = s.GetGender();
                cell5.ValueType = typeof(double);
                cell5.Value = s.GetHeight();
                cell6.ValueType = typeof(double);
                cell6.Value = s.GetWeight();
                cell7.ValueType = typeof(string);
                cell7.Value = s.GetSport();
                cell8.ValueType = typeof(double);
                cell8.Value = s.GetStatus();
                cell9.ValueType = typeof(double);
                cell9.Value = s.GetGoodweight();
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                row.Cells.Add(cell4);
                row.Cells.Add(cell5);
                row.Cells.Add(cell6);
                row.Cells.Add(cell7);
                row.Cells.Add(cell8);
                row.Cells.Add(cell9);
                dataGridView1.Rows.Add(row);
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("surname", "Фамилия");
            dataGridView1.Columns.Add("name", "Имя");
            dataGridView1.Columns.Add("otc", "Отчество");
            dataGridView1.Columns.Add("gender", "Пол");
            dataGridView1.Columns.Add("height", "Рост");
            dataGridView1.Columns.Add("weight", "Вес");
            dataGridView1.Columns.Add("sport", "Вид спорта");
            dataGridView1.Columns.Add("status", "Статус");
            dataGridView1.Columns.Add("goodweight", "Идеальный вес");
        }

        private bool Digit(string text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                if (char.IsDigit(text[i]))
                    return false;
            }
            
            return true;
        }
        
        private bool WhiteSpace(string text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                if (!char.IsWhiteSpace(text[i]))
                    return false;
            }
            return true;
        }

        private void apply_Click(object sender, EventArgs e)
        {
            if (!Digit(name.Text)|| !Digit(surname.Text) || !Digit(otc.Text))
                MessageBox.Show("Заполните поля имени ТОЛЬКО БУКВАМИ!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (Digit(height.Text)|| Digit(weight.Text))
                MessageBox.Show("Заполните рост и вес спортсмена ТОЛЬКО ЦИФРАМИ!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (WhiteSpace(name.Text))
                MessageBox.Show("Заполните поле имени!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (WhiteSpace(surname.Text))
                MessageBox.Show("Заполните поле фамилии!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (WhiteSpace(otc.Text))
                MessageBox.Show("Заполните поле отчества!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (WhiteSpace(height.Text))
                MessageBox.Show("Заполните поле роста!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (WhiteSpace(weight.Text))
                MessageBox.Show("Заполните поле веса!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (WhiteSpace(sport.Text))
                MessageBox.Show("Заполните поле вида спорта!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (!Digit(sport.Text))
                MessageBox.Show("Заполните поле спорта ТОЛЬКО БУКВАМИ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (!men.Checked &&!women.Checked )
                MessageBox.Show("Выберите пол спортсмена!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                if (men.Checked == true || women.Checked == false)
                {
                    addSportsmen(name.Text, otc.Text, surname.Text, "Мужчина", Convert.ToDouble(height.Text), Convert.ToDouble(weight.Text), sport.Text); ;

                }
                else if (men.Checked == false || women.Checked == true)
                {
                    addSportsmen(name.Text, otc.Text, surname.Text, "Женщина", Convert.ToDouble(height.Text), Convert.ToDouble(weight.Text), sport.Text);
                }
                avg_text.Text = (Sportsmen.allweight / Convert.ToDouble(Sportsmen.kolvo)).ToString();
            }

            //name.Text = "";
        }

        private void men_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void women_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void name_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void otc_TextChanged(object sender, EventArgs e)
        {

        }

        private void surname_TextChanged(object sender, EventArgs e)
        {

        }

        private void avg_text_Click(object sender, EventArgs e)
        {

        }
    }
}
