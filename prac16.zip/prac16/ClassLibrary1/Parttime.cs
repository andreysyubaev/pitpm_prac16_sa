﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Parttime: Class1
    {
        double timework;
        double hourpay;
        string company;
    }
}
